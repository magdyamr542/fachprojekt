import os
from patrec.serialization.list_io import LineListIO

queries = []
for filename in os.listdir('.'):
    annotations = LineListIO.read_list(filename)
    queries.extend(['%s.png %s' % (filename.split('.')[0], elem) for elem in annotations])
LineListIO.write_list('queries.gtp', sorted(queries))
